public class classePrincipale
{
    public static void main(String[] args)
    {
        fenetreMenu menu = new fenetreMenu();
    }
}